﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Adoptex.Utility
{
    public class SD
    {
        public const string AdminEndUser = "Admin";
        public const string CustomerEndUser = "User";
    }
}
